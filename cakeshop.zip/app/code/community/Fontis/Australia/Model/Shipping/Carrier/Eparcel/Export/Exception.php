<?php

class Fontis_Australia_Model_Shipping_Carrier_Eparcel_Export_Exception extends Mage_Core_Exception
{
}
